﻿using CKK.Logic.Models;
using CKK.Persistance.Models;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace CKK.MockClient
{
    public class Client
    {
        private static Socket sck = null;
        private static EndPoint epLocal;
        private static EndPoint epRemote;
        private static byte[] buffer;

        private static FileStore store;
        private static ShoppingCart cart;

        static void Main(string[] args)
        {
            Connect();
            SendCart();
            StartListening();
        }

        private static string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }

        private static void SendCart()
        {
            Console.WriteLine("Sending cart");

            // PRODUCTS
            Product prod1 = new Product();
            prod1.Id = 1;
            prod1.Price = 0.50m;
            prod1.Name = "Banana";

            ShoppingCartItem itm1 = new ShoppingCartItem(prod1, 3);

            Customer cust = new Customer();
            cust.CustomerID = 1;
            cust.ShoppingCartID = 1;
            cust.Address = "123 Fake St.";
            cust.Name = "Carl";

            cart = new ShoppingCart(cust);
            cart.CustomerID = 1;
            cart.ShoppingCartID = 1;
            cart.Products.Add(itm1);

            try
            {
                byte[] msg = JsonSerializer.SerializeToUtf8Bytes<object>(cart);
                int bytesSent = sck.Send(msg);

                //sck.Shutdown(SocketShutdown.Both);
                //sck.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public static void StartListening()
        {
            try
            {
                //sck.Listen();
                buffer = new byte[1500];
                sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageCallBack), buffer);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }

        private static void MessageCallBack(IAsyncResult aResult)
        {
            try
            {
                int size = sck.EndReceiveFrom(aResult, ref epRemote);

                if (size > 0)
                {
                    byte[] receivedData = new byte[1500];
                    receivedData = (byte[])aResult.AsyncState;

                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receivedMessage = eEncoding.GetString(receivedData);

                    Console.WriteLine(receivedMessage);
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.ToString());
            }
        }

        private static void Connect()
        {
            try
            {
                IPAddress iPAddress = IPAddress.Parse(GetLocalIP());
                epLocal = new IPEndPoint(iPAddress, 11001);
                epRemote = new IPEndPoint(iPAddress, 11000);

                sck = new(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                sck.Bind(epLocal);
                sck.Connect(epRemote);
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
                Console.WriteLine("Error Connecting");
            }
        }

        /*
        private static void MessageCallBack(IAsyncResult aResult)
        {
            try
            {
                int size = sck.EndReceiveFrom(aResult, ref epRemote);

                if (size > 0)
                {
                    byte[] receivedData = new byte[1500];
                    receivedData = (byte[])aResult.AsyncState;

                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receivedMessage = eEncoding.GetString(receivedData);
                    Console.WriteLine(receivedMessage);
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
                // Send string message to client
                Console.WriteLine("Sending error message");
            }
        }
        */
    }
}
