﻿using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;

namespace CKK.Server
{
    /*
    public class Server
    {
        public static ShoppingCart cart;
        public static List<ShoppingCart> cartsInQueue = new List<ShoppingCart>();

        public static void Main(string[] args)
        {
            StartListening();
        }

        private static string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }

        static void ReadBufferToCart(byte[] receivedData)
        {
            var utf8Reader = new Utf8JsonReader(receivedData);
            try
            {
                var json = (JsonElement)JsonSerializer.Deserialize<object>(ref utf8Reader);
                cart = json.ToObject<ShoppingCart>();

                cartsInQueue.Add(cart);
                Console.WriteLine("The cart has been received!");
                Console.WriteLine("The cart's position in line is: " + cartsInQueue.Count.ToString());
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
                Console.WriteLine("Error reding cart");
            }
        }

        private static void StartListening()
        {
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress iPAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(iPAddress, 11000);

            Socket listenerSocket = new(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //Connect();
            listenerSocket.Bind(localEndPoint);
            listenerSocket.Listen();

            bool _do = true;
            do
            {
                Console.WriteLine("Waiting");
                Socket socketHandler = listenerSocket.Accept();
            } while (_do);
        }

        /*
        private static void MessageCallBack(IAsyncResult aResult)
        {
            try
            {
                int size = sck.EndReceiveFrom(aResult, ref epRemote);

                if (size > 0)
                {
                    byte[] receivedData = new byte[1500];
                    receivedData = (byte[])aResult.AsyncState;

                    ReadBufferToCart(receivedData);

                    System.Threading.Thread.Sleep(5000);

                    // Send string message to client
                    Console.WriteLine("Sending success message");
                    SendMessage("Successfully received cart!");

                    Console.WriteLine("Shutting down");
                    sck.Shutdown(SocketShutdown.Both);
                    sck.Close();

                    Connect();
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
                // Send string message to client
                Console.WriteLine("Sending error message");
                SendMessage("Error receiving cart!");
            }
        }

        static void SendMessage(string msgString)
        {
            ASCIIEncoding enc = new ASCIIEncoding();
            byte[] msg = new byte[1500];
            msg = enc.GetBytes(msgString);
            sck.Send(msg);
        }
    }
    */

    class Server
    {
        private static Queue<Order> ShoppingQueue = new();
        public static void StartListening()
        {
            byte[] buffer = new byte[1500];

            //IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            //IPAddress iPAddress = ipHostInfo.AddressList[0];
            IPAddress iPAddress = IPAddress.Parse(GetLocalIP());
            IPEndPoint localEndPoint = new IPEndPoint(iPAddress, 11000);

            Socket listenerSocket = new(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);


            try
            {
                listenerSocket.Bind(localEndPoint);
                listenerSocket.Listen();

                while (true)
                {
                    Console.WriteLine($"Waiting for a connection...");
                    Socket handler = listenerSocket.Accept();
                    Order order = null;
                    byte[] msg = null;
                    while (true)
                    {
                        int bytesRecieved = handler.Receive(buffer);
                        var utf8Reader = new Utf8JsonReader(buffer);
                        try
                        {
                            var json = (JsonElement)JsonSerializer.Deserialize<object>(ref utf8Reader);
                            order = json.ToObject<Order>();
                            msg = Encoding.Default.GetBytes($"Successfully added order to the queue. There are {ShoppingQueue.Count} orders ahead of you.");
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("Object failed to deserialize.");
                            msg = Encoding.Default.GetBytes("Object Failed to be processed.");
                        }
                        break;
                    }
                    if (order != null)
                    {
                        ShoppingQueue.Enqueue(order);
                        Console.WriteLine($"Order Recieved!");
                        Console.WriteLine($"There are {ShoppingQueue.Count} orders in the queue. ");
                    }
                    else
                    {
                        Console.WriteLine("Failed to Add ShoppingCart");
                    }
                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }

        static void Main(string[] args)
        {
            StartListening();
        }

        private static string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }
    }

    static class JsonExtention
    {
        public static T ToObject<T>(this JsonElement element)
        {
            var json = element.GetRawText();
            return JsonSerializer.Deserialize<T>(json);
        }
    }
}
