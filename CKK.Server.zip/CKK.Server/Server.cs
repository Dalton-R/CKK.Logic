﻿using CKK.Logic.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace CKK.Server
{
    public class Server
    {
        private static Queue<Order> ShoppingQueue = new();
        public static void StartListening()
        {
            byte[] buffer = new byte[1500];

            IPAddress iPAddress = IPAddress.Parse(GetLocalIP());
            IPEndPoint localEndPoint = new IPEndPoint(iPAddress, 11000);

            Socket listenerSocket = new(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);


            try
            {
                listenerSocket.Bind(localEndPoint);
                listenerSocket.Listen();

                while (true)
                {
                    Console.WriteLine($"Waiting for a connection...");
                    Socket handler = listenerSocket.Accept();
                    Order order = null;
                    byte[] msg = null;
                    while (true)
                    {
                        int bytesRecieved = handler.Receive(buffer);
                        var utf8Reader = new Utf8JsonReader(buffer);
                        try
                        {
                            var json = (JsonElement)JsonSerializer.Deserialize<object>(ref utf8Reader);
                            order = json.ToObject<Order>();
                            if(ShoppingQueue.Count == 0)
                            {
                                msg = Encoding.Default.GetBytes($"Successfully added order to the queue. You are first in line!");
                            }
                            else
                            {
                                msg = Encoding.Default.GetBytes($"Successfully added order to the queue. There are {ShoppingQueue.Count} orders ahead of you.");
                            }
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("Object failed to deserialize.");
                            msg = Encoding.Default.GetBytes("Object Failed to be processed.");
                        }
                        break;
                    }
                    if (order != null)
                    {
                        ShoppingQueue.Enqueue(order);
                        Console.WriteLine($"Order Recieved!");
                        
                        Console.WriteLine($"There are {ShoppingQueue.Count} orders in the queue.");
                    }
                    else
                    {
                        Console.WriteLine("Failed to Add ShoppingCart");
                    }
                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();
        }

        static void Main(string[] args)
        {
            StartListening();
        }

        private static string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }
    }

    static class JsonExtention
    {
        public static T ToObject<T>(this JsonElement element)
        {
            var json = element.GetRawText();
            return JsonSerializer.Deserialize<T>(json);
        }
    }
}






// HELPFUL CODE

//IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
//IPAddress iPAddress = ipHostInfo.AddressList[0];