﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CKK.Online.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _products;
        private readonly IShoppingCartItemRepository _items;

        private Socket sck = null;
        private EndPoint epLocal;
        private EndPoint epRemote;
        private byte[] buffer;

        public static string checkoutString = "";
        public static string errorString = "";

        public ProductController(IProductRepository products, IShoppingCartItemRepository items)
        {
            _products = products;
            _items = items;
        }

        // GET: ProductController
        public ActionResult Index()
        {
            List<Product> _returnProducts = new List<Product>();
            foreach(Product _prod in _products.GetAll())
            {
                if(_prod.Quantity < 1)
                {
                    continue;
                }
                Product _proNew = new Product();
                _proNew.Id = _prod.Id;
                _proNew.Price = _prod.Price;
                _proNew.Name = _prod.Name;
                _proNew.Quantity = _prod.Quantity;
                _proNew.CartCount = _prod.CartCount;
                _returnProducts.Add(_proNew);
            }
            return View(_returnProducts);
        }

        // GET: ProductController/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var product = _products.Find(id ?? 0);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add(IFormCollection collection)
        {
            try
            {
                var id = Convert.ToInt32(collection["Id"]);
                var quantity = Convert.ToInt32(collection["CartCount"]);
                if (quantity < 1)
                {
                    return RedirectToAction(nameof(Index));
                }
                SetItm(id, quantity);
                return RedirectToAction(nameof(Cart));
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }

        void SetItm(int id, int quantity)
        {
            int _finalValue = quantity;

            Product _prod = _products.Find(id);
            if (_prod != null)
            {
                if (_finalValue > _prod.Quantity)
                {
                    _finalValue = _prod.Quantity;
                }
            }

            bool _added = false;
            foreach(ShoppingCartItem itm in _items.GetAll())
            {
                if(itm.ProductId == id)
                {
                    _added = true;
                    break;
                }
            }

            if(_added)
            {
                var shoppingCartItem = new ShoppingCartItem
                {
                    ShoppingCartId = 1,
                    CustomerId = 1,
                    ProductId = id,
                    Quantity = _finalValue
                };

                _items.Update(shoppingCartItem);
            }
            else
            {
                var shoppingCartItem = new ShoppingCartItem
                {
                    ShoppingCartId = 1,
                    CustomerId = 1,
                    ProductId = id,
                    Quantity = _finalValue
                };

                _items.Add(shoppingCartItem);
            }
        }

        public ActionResult Remove(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            _items.RemoveById((int)id);

            return RedirectToAction(nameof(Cart));
        }

        public ActionResult Cart()
        {
            var productList = _items.GetAll().ToList();
            List<Product> cartProducts = new List<Product>();
            foreach(ShoppingCartItem itm in productList)
            {
                Product _prod = _products.Find(itm.ProductId);
                if(_prod != null)
                {
                    _prod.CartCount = itm.Quantity;
                    cartProducts.Add(_prod);
                }
            }

            return View(cartProducts);
        }

        public ActionResult Checkout()
        {
            var productList = _items.GetAll().ToList();
            List<Product> cartProducts = new List<Product>();
            foreach (ShoppingCartItem itm in productList)
            {
                Product _prod = _products.Find(itm.ProductId);
                if (_prod != null)
                {
                    _prod.CartCount = itm.Quantity;
                    cartProducts.Add(_prod);
                }
            }

            if (cartProducts.Count > 0)
            {
                return View(cartProducts);
            }
            else
            {
                return RedirectToAction(nameof(Cart));
            }
        }

        public ActionResult Payment()
        {
            decimal _totalVal = _items.GetTotal(1, _products.GetAll().ToList());
            return View(_totalVal);
        }

        public ActionResult SendCartPage()
        {
            return RedirectToAction(nameof(CheckoutComplete));
        }

        public ActionResult ErrorPage()
        {
            Console.WriteLine("ERROR: " + errorString);
            if (string.IsNullOrEmpty(errorString) || string.IsNullOrWhiteSpace(errorString))
            {
                errorString = "Something went wrong";
            }
            return View((object)errorString);
        }

        public async Task<ActionResult> CheckoutComplete()
        {
            try
            {
                SendCart();

                if(!sck.Connected)
                {
                    errorString = "Not connected to server!";
                    return RedirectToAction(nameof(ErrorPage));
                }

                await Task.WhenAll(StartListening());
                return View((object)checkoutString);
            }catch(Exception ex)
            {
                errorString = ex.Message;
                return RedirectToAction(nameof(ErrorPage));
            }
        }

        private void Connect()
        {
            try
            {
                IPAddress iPAddress = IPAddress.Parse(GetLocalIP());
                epLocal = new IPEndPoint(iPAddress, 11001);
                epRemote = new IPEndPoint(iPAddress, 11000);

                sck = new(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                sck.Bind(epLocal);
                sck.Connect(epRemote);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Connecting: " + ex.Message);
                errorString = ex.Message;
            }
        }

        private string GetLocalIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }

        private void SendCart()
        {
            Connect();

            Console.WriteLine("Sending cart");

            Customer cust = new Customer();
            cust.CustomerID = 1;
            cust.ShoppingCartID = 1;
            cust.Address = "123 Fake St.";
            cust.Name = "Carl";

            ShoppingCart cart = new ShoppingCart(cust);
            cart.CustomerId = 1;
            cart.ShoppingCartId = 1;
            foreach (ShoppingCartItem itm in _items.GetAll())
            {
                cart.Products.Add(itm);
            }

            try
            {
                byte[] msg = JsonSerializer.SerializeToUtf8Bytes<object>(cart);
                int bytesSent = sck.Send(msg);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                errorString = ex.Message;
            }
        }

        public async Task<int> StartListening()
        {
            checkoutString = "";

            try
            {
                buffer = new byte[1500];
                await Task.Run(() => sck.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epRemote, new AsyncCallback(MessageCallBack), buffer));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                errorString = ex.Message;
            }

            do
            {
                await Task.Delay(1000);
            } while (checkoutString == "");

            sck.Shutdown(SocketShutdown.Both);
            sck.Close();

            return 0;
        }

        private void MessageCallBack(IAsyncResult aResult)
        {
            try
            {
                int size = sck.EndReceiveFrom(aResult, ref epRemote);

                if (size > 0)
                {
                    byte[] receivedData = new byte[1500];
                    receivedData = (byte[])aResult.AsyncState;

                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receivedMessage = eEncoding.GetString(receivedData);

                    receivedMessage = receivedMessage.Replace("\0", string.Empty);
                    Console.WriteLine(receivedMessage);
                    checkoutString = receivedMessage;

                    bool _success = false;

                    if(receivedMessage.Substring(0, 12) == "Successfully")
                    {
                        _success = true;
                    }

                    if (_success)
                    {
                        foreach (Product pro in _products.GetAll())
                        {
                            int _finalAmount = pro.Quantity;
                            foreach (ShoppingCartItem itm in _items.GetAll())
                            {
                                if (itm.ProductId == pro.Id)
                                {
                                    _finalAmount -= itm.Quantity;
                                    break;
                                }
                            }

                            if (_finalAmount < 0)
                            {
                                _finalAmount = 0;
                            }

                            Product _proNew = new Product();
                            _proNew.Id = pro.Id;
                            _proNew.Price = pro.Price;
                            _proNew.Name = pro.Name;
                            _proNew.Quantity = _finalAmount;
                            _proNew.CartCount = pro.CartCount;
                            _products.Update(_proNew);
                        }
                        foreach (ShoppingCartItem itm in _items.GetAll())
                        {
                            Remove(itm.ProductId);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                errorString = ex.Message;
            }
        }
    }
}





// HELPFUL CODE

//sck.Shutdown(SocketShutdown.Both);
//sck.Close();

/*
private readonly IProductRepository _products;
private readonly ShoppingCart _cart;
//private readonly IShoppingCart _cart;

public ProductController(IProductRepository products, ShoppingCart cart)
{
    _products = products;
    _cart = cart;
}

// GET: ProductController
public ActionResult Index()
{
    var productList = _products.GetAll().ToList();
    return View(productList);
}

// GET: ProductController/Details/5
public ActionResult Details(int? id)
{
    if (id == null)
    {
        return NotFound();
    }
    var product = _products.Find(id ?? 0);
    if (product == null)
    {
        return NotFound();
    }
    return View(product);
}

// POST: ProductController/Edit/5
[HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Add(IFormCollection collection)
{
    try
    {
        var id = Convert.ToInt32(collection["id"]);
        var quantity = Convert.ToInt32(collection["cartCount"]);
        _cart.AddProduct(_products.Find(id), quantity);
        return RedirectToAction(nameof(Cart));
    }
    catch
    {
        return RedirectToAction(nameof(Index));
    }
}

public ActionResult Cart()
{
    var productList = _cart.GetProducts();
    //var productList = _cart.Products;
    //var productList = new List<ShoppingCartItem>();
    _cart.AddProduct(_products.Find(3), 1);


    return View(productList);
    //return View();
}
*/
