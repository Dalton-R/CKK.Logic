﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using CKK.Persistance.Interfaces;

namespace CKK.Persistance.Models
{
    public class FileStore : IStore, ISavable, ILoadable
    {
        public List<StoreItem> Items = new List<StoreItem>();

        private string filePath;

        public string FilePath
        {
            get
            {
                return filePath;
            }
            set
            {
                filePath = value;
            }
        }

        List<StoreItem> IStore.Items { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        //List<StoreItem> IStore.Items { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public StoreItem AddStoreItem(Product prod, int quantity)
        {
            if (prod == null || quantity <= 0)
            {
                return null;
            }

            bool exists = false;
            int index = -1;

            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct() == prod)
                {
                    exists = true;
                    index = i;
                    break;
                }
            }

            if (exists)
            {
                Items[index].SetQuantity(Items[index].GetQuantity() + quantity);
            }
            else
            {
                Items.Add(new StoreItem(prod, quantity));
                index = Items.Count - 1;
            }

            if (Items[index].GetProduct().Id == 0)
            {
                Random rand = new Random();
                Items[index].GetProduct().Id = rand.Next(1, 9999);
            }

            Save();
            return Items[index];
        }

        public StoreItem RemoveStoreItem(int id, int quantity)
        {
            int index = -1;

            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().Id == id)
                {
                    index = i;

                    Items[i].SetQuantity(Items[i].GetQuantity() - quantity);
                    if (Items[i].GetQuantity() < 0)
                    {
                        Items[i].SetQuantity(0);
                    }

                    break;
                }
            }

            Save();

            if (index != -1)
            {
                return Items[index];
            }
            else
            {
                return null;
            }
        }

        public void DeleteStoreItem(int id)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().Id == id)
                {
                    Items.RemoveAt(i);
                    break;
                }
            }

            Save();
        }

        public StoreItem FindStoreItemById(int id)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().Id == id)
                {
                    return Items[i];
                }
            }

            return null;
        }

        public List<StoreItem> GetStoreItems()
        {
            return Items;
        }

        public List<StoreItem> GetAllProductsByName(string name)
        {
            //This function should should return a List<StoreItem> that has all of the items that match the search. You can choose if you would like it to be any letter(s) that match, or if it is just the beginning that you compare. Your results don't necessarily have to be in any order, but it could be alphabetical.
            return SortByName(Items, name);
        }

        public List<StoreItem> GetProductsByQuantity()
        {
            //This should return a List<StoreItems> that are sorted by quantity. (highest to lowest)
            return BubbleSortQuantity(Items);
        }

        public List<StoreItem> GetProductsByPrice()
        {
            //This should return a List<StoreItems> that are sorted by Price. (highest to lowest)
            return BubbleSortPrice(Items);
        }

        private List<StoreItem> SortByName(List<StoreItem> values, string name)
        {
            List<StoreItem> _values = new List<StoreItem>();
            foreach (StoreItem si in values)
            {
                if (si.GetProduct().Name.Contains(name))
                {
                    _values.Add(si);
                }
            }
            return _values;
        }

        private List<StoreItem> BubbleSortQuantity(List<StoreItem> values)
        {
            List<StoreItem> _values = values;

            if (_values.Count > 1)
            {
                bool _return = true;

                for (int i = _values.Count - 1; i > 0; i--)
                {
                    if (_values[i - 1].GetQuantity() < _values[i].GetQuantity())
                    {
                        _return = false;

                        StoreItem _num = _values[i - 1];
                        _values.RemoveAt(i - 1);
                        _values.Insert(i, _num);
                    }
                }

                if (_return)
                {
                    return _values;
                }
                else
                {
                    BubbleSortQuantity(_values);
                }
            }
            else
            {
                return _values;
            }

            return _values;
        }

        private List<StoreItem> BubbleSortPrice(List<StoreItem> values)
        {
            List<StoreItem> _values = values;

            if (_values.Count > 1)
            {
                bool _return = true;

                for (int i = _values.Count - 1; i > 0; i--)
                {
                    if (_values[i - 1].GetProduct().Price < _values[i].GetProduct().Price)
                    {
                        _return = false;

                        StoreItem _num = _values[i - 1];
                        _values.RemoveAt(i - 1);
                        _values.Insert(i, _num);
                    }
                }

                if (_return)
                {
                    return _values;
                }
                else
                {
                    BubbleSortPrice(_values);
                }
            }
            else
            {
                return _values;
            }

            return _values;
        }

        public FileStore()
        {
            CreatePath();
        }

        public void Save()
        {
            string jsonString = JsonSerializer.Serialize(Items);
            File.WriteAllText(FilePath, jsonString);

            //Console.WriteLine("Saved File: " + jsonString);
        }

        public void Load()
        {
            if (File.Exists(FilePath))
            {
                string jsonString = File.ReadAllText(FilePath);
                Items = JsonSerializer.Deserialize<List<StoreItem>>(jsonString);
            }
            else
            {
                Save();
            }
        }

        public void CreatePath()
        {
            FilePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + Path.DirectorySeparatorChar + "Persistance" + Path.DirectorySeparatorChar + "StoreItems.dat";
        }
    }
}
