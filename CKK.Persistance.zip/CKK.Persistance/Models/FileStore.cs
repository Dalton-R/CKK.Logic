﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using CKK.Persistance.Interfaces;

namespace CKK.Persistance.Models
{
    public class FileStore : ISavable, ILoadable
    {
        public List<StoreItem> Items = new List<StoreItem>();

        private string filePath;

        public string FilePath
        {
            get
            {
                return filePath;
            }
            set
            {
                filePath = value;
            }
        }

        //List<StoreItem> IStore.Items { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public StoreItem AddStoreItem(Product prod, int quantity)
        {
            if (prod == null || quantity <= 0)
            {
                return null;
            }

            bool exists = false;
            int index = -1;

            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct() == prod)
                {
                    exists = true;
                    index = i;
                    break;
                }
            }

            if (exists)
            {
                Items[index].SetQuantity(Items[index].GetQuantity() + quantity);
            }
            else
            {
                Items.Add(new StoreItem(prod, quantity));
                index = Items.Count - 1;
            }

            if (Items[index].GetProduct().GetId() == 0)
            {
                Random rand = new Random();
                Items[index].GetProduct().SetId(rand.Next(1, 9999));
            }

            Save();
            return Items[index];
        }

        public StoreItem RemoveStoreItem(int id, int quantity)
        {
            int index = -1;

            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().GetId() == id)
                {
                    index = i;

                    Items[i].SetQuantity(Items[i].GetQuantity() - quantity);
                    if (Items[i].GetQuantity() < 0)
                    {
                        Items[i].SetQuantity(0);
                    }

                    break;
                }
            }

            Save();

            if (index != -1)
            {
                return Items[index];
            }
            else
            {
                return null;
            }
        }

        public void DeleteStoreItem(int id)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().GetId() == id)
                {
                    Items.RemoveAt(i);
                    break;
                }
            }

            Save();
        }

        public StoreItem FindStoreItemById(int id)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].GetProduct().GetId() == id)
                {
                    return Items[i];
                }
            }

            return null;
        }

        public List<StoreItem> GetStoreItems()
        {
            return Items;
        }

        public FileStore()
        {
            CreatePath();
        }

        public void Save()
        {
            string jsonString = JsonSerializer.Serialize(Items);
            File.WriteAllText(FilePath, jsonString);

            //Console.WriteLine("Saved File: " + jsonString);
        }

        public void Load()
        {
            if (File.Exists(FilePath))
            {
                string jsonString = File.ReadAllText(FilePath);
                Items = JsonSerializer.Deserialize<List<StoreItem>>(jsonString);
            }
            else
            {
                Save();
            }
        }

        public void CreatePath()
        {
            FilePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + Path.DirectorySeparatorChar + "Persistance" + Path.DirectorySeparatorChar + "StoreItems.dat";
        }
    }
}
