﻿using CKK.Logic.Interfaces;
using System;

namespace CKK.Logic.Models
{
    [Serializable]
    public class Customer : Entity
    {
        public int CustomerID { get; set; }
        public int ShoppingCartID { get; set; }
        public ShoppingCart Cart { get; set; }
        public string Address { get; set; }

        public int Id { get; set; }

        public string Name { get; set; }
    }
}
