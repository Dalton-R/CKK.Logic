﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Interfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CKK.Logic.Models
{
    public class ShoppingCartItemRepository : IShoppingCartItemRepository
    {
        private readonly IConnectionFactory _connectionFactory;
        private readonly string _tableName = "ShoppingCarts";

        public ShoppingCartItemRepository(IConnectionFactory factory)
        {
            _connectionFactory = factory;
        }

        public void Add(ShoppingCartItem entity)
        {
            /*
            using (var conn = _connectionFactory.GetConnection)
            {
                List<ShoppingCartItem> _in = GetAll().ToList();
                string insertQuery = "";

                bool _added = false;

                foreach (ShoppingCartItem itm in _in)
                {
                    if (itm.ProductId == entity.ProductId)
                    {
                        _added = true;
                        //int _quant = itm.Quantity + entity.Quantity;
                        int _quant = entity.Quantity;
                        if (_quant > 0)
                        {
                            insertQuery = $"UPDATE [dbo].[ShoppingCarts] SET Quantity = {_quant} WHERE ProductId = {entity.ProductId}";
                        }
                        else
                        {
                            RemoveById(entity.ProductId);
                            return;
                        }
                        break;
                    }
                }

                if (!_added)
                {
                    insertQuery = @"INSERT INTO [dbo].[ShoppingCarts]([ShoppingCartId], [CustomerId], [ProductId], [Quantity]) VALUES (@ShoppingCartId, @CustomerId, @ProductId, @Quantity)";
                }

                SqlMapper.Execute(conn, insertQuery, entity);
            }
            */

            using (var conn = _connectionFactory.GetConnection)
            {
                List<ShoppingCartItem> _in = GetAll().ToList();
                string insertQuery = @"INSERT INTO [dbo].[ShoppingCarts]([ShoppingCartId], [CustomerId], [ProductId], [Quantity]) VALUES (@ShoppingCartId, @CustomerId, @ProductId, @Quantity)";
                SqlMapper.Execute(conn, insertQuery, entity);
            }
        }

        public ShoppingCartItem AddToCart(int itemId, int quantity)
        {
            throw new NotImplementedException();
        }

        public ShoppingCartItem AddToCart(string itemName, int quantity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<ShoppingCartItem> GetAll()
        {
            using (var conn = _connectionFactory.GetConnection)
            {
                var result = SqlMapper.Query<ShoppingCartItem>(conn, $"SELECT * FROM {_tableName}");
                return result;
            }
        }

        public IEnumerable<Product> GetAllShoppingCartItems()
        {
            throw new NotImplementedException();
        }

        public int GetCustomerId(int shoppingCartId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<ShoppingCartItem> GetShoppingCartItems()
        {
            throw new NotImplementedException();
        }

        public decimal GetTotal(int shoppingCartId, List<Product> _products)
        {
            decimal _total = 0.00m;
            foreach(ShoppingCartItem itm in GetAll())
            {
                if(itm.ShoppingCartId == shoppingCartId)
                {
                    foreach(Product prod in _products)
                    {
                        if(itm.ProductId == prod.Id)
                        {
                            _total += itm.Quantity * prod.Price;
                        }
                    }
                }
            }

            return _total;
        }

        public void Remove(ShoppingCartItem entity)
        {
            using (var conn = _connectionFactory.GetConnection)
            {
                SqlMapper.Execute(conn, $"DELETE FROM {_tableName} WHERE ProductId=@ProductId", new { Id = entity.ProductId });
            }
        }

        public void RemoveById(int id)
        {
            using (var conn = _connectionFactory.GetConnection)
            {
                SqlMapper.Execute(conn, $"DELETE FROM {_tableName} WHERE ProductId=@id", new { Id = id });
            }
        }

        public ShoppingCartItem RemoveFromCart(int shoppingCartId, int itemId, int quantity = 1)
        {
            throw new NotImplementedException();
        }

        public void Update(ShoppingCartItem entity)
        {
            var query = $"UPDATE {_tableName} SET ShoppingCartId = @ShoppingCartId, CustomerId = @CustomerId, ProductId = @ProductId, Quantity = @Quantity WHERE ProductId = @ProductId";
            var parameters = new DynamicParameters();
            parameters.Add("ShoppingCartId", entity.ShoppingCartId, DbType.Int32);
            parameters.Add("CustomerId", entity.CustomerId, DbType.Int32);
            parameters.Add("ProductId", entity.ProductId, DbType.Int32);
            parameters.Add("Quantity", entity.Quantity, DbType.Int32);
            using (var conn = _connectionFactory.GetConnection)
            {
                SqlMapper.Execute(conn, query, parameters);
            }
        }
    }
}
