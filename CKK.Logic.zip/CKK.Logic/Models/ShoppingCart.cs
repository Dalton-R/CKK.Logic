﻿using CKK.Logic.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CKK.Logic.Models
{
    public class ShoppingCart : IShoppingCart
    {
        public ShoppingCart(Customer cust)
        {
            Customer = cust;
        }

        public Customer Customer { get; set; }

        public int ShoppingCartId { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }

        public List<ShoppingCartItem> Products { get; set; } = new List<ShoppingCartItem>();
    }
}
