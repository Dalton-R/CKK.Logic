﻿using CKK.Logic.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CKK.Logic.Models
{
    public class ShoppingCart
    {
        public ShoppingCart(Customer cust)
        {
            Customer = cust;
        }

        public Customer Customer { get; set; }

        public int ShoppingCartId { get; set; }
        public int CustomerId { get; set; }

        public List<ShoppingCartItem> Products { get; set; } = new List<ShoppingCartItem>();

        /*
        public int GetCustomerId()
        {
            return CustomerId;
        }

        public ShoppingCartItem AddProduct(Product prod, int Quantity)
        {
            if (prod == null || Quantity <= 0)
            {
                return null;
            }

            bool exists = false;
            int index = -1;

            for (int i = 0; i < Products.Count; i++)
            {
                if (Products[i].ProductId == prod.Id)
                {
                    exists = true;
                    index = i;
                    break;
                }
            }

            if (exists)
            {
                Products[index].Quantity = (Products[index].Quantity + Quantity);
            }
            else
            {
                Products.Add(new ShoppingCartItem
                {
                    CustomerId = 1,
                    ShoppingCartId = 1,
                    ProductId = prod.Id,
                    Quantity = Quantity
                });
                index = Products.Count - 1;
            }

            if (Products[index].ProductId == 0)
            {
                int _index = 1;
                bool _repeat = true;
                do
                {
                    bool _containsID = false;
                    foreach(ShoppingCartItem itm in Products)
                    {
                        if(itm.ProductId == _index)
                        {
                            _containsID = true;
                        }
                    }

                    if(_containsID)
                    {
                        _index++;
                    }
                    else
                    {
                        _repeat = false;
                    }
                } while (_repeat);

                Products[index].ProductId = _index;
            }

            return Products[index];
        }

        public ShoppingCartItem GetProductById(int id)
        {
            for (int i = 0; i < Products.Count; i++)
            {
                if (Products[i].ProductId == id)
                {
                    return Products[i];
                }
            }

            return null;
        }

        public List<ShoppingCartItem> GetProducts()
        {
            return Products;
        }

        public decimal GetTotal()
        {
            throw new NotImplementedException();
        }

        public ShoppingCartItem RemoveProduct(int id, int Quantity)
        {
            int index = -1;

            for (int i = 0; i < Products.Count; i++)
            {
                if (Products[i].ProductId == id)
                {
                    index = i;

                    Products[i].Quantity = (Products[i].Quantity - Quantity);
                    if (Products[i].Quantity < 0)
                    {
                        Products[i].Quantity = 0;
                    }

                    break;
                }
            }

            if (index != -1)
            {
                return Products[index];
            }
            else
            {
                return null;
            }
        }
        */
    }
}
