﻿using CKK.Logic.Repository.Interfaces;
using System.Data;
using System.Data.Common;

namespace CKK.Logic.Repository.Implementation
{
    public class DatabaseConnectionFactory : IConnectionFactory
    {
        //private readonly string connectionString = @"Data Source = DESKTOP-GB9T2LJ\SQLEXPRESS;Initial Catalog = StructuredProjectDB";
        private readonly string connectionString = @"Data Source = DESKTOP-GB9T2LJ\SQLEXPRESS;Database=StructuredProjectDB;Trusted_Connection=true;";

        public IDbConnection GetConnection
        {
            get
            {
                DbProviderFactories.RegisterFactory("System.Data.SqlClient", System.Data.SqlClient.SqlClientFactory.Instance);
                var factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                var conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;
                conn.Open();
                return conn;
            }
        }
    }
}
