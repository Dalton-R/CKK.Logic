﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CKK.Logic.Models;
using CKK.Logic.Repository.Interfaces;
using CKK.Logic.Interfaces;

namespace CKK.Logic.Repository.Interfaces
{
    public interface IShoppingCartItemRepository : IRepository<ShoppingCartItem>
    {
        public int GetCustomerId(int shoppingCartId);
        public ShoppingCartItem AddToCart(int itemId, int quantity);
        public ShoppingCartItem AddToCart(string itemName, int quantity);
        public ShoppingCartItem RemoveFromCart(int shoppingCartId, int itemId, int quantity = 1);
        public decimal GetTotal(int shoppingCartId, List<Product> _products);
        public void RemoveById(int id);
        public IEnumerable<Product> GetAllShoppingCartItems();
        public IEnumerable<ShoppingCartItem> GetShoppingCartItems();
    }
}
