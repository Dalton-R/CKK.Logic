﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CKK.Logic.Repository.Memory
{
    public class StoreItemRepository : IStoreItemRepository
    {
        public void Add(StoreItem entity)
        {
            throw new NotImplementedException();
        }

        public StoreItem Find(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<StoreItem> Find(string name)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<StoreItem> GetAll()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<StoreItem> GetItemsByPrice()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<StoreItem> GetItemsByQuantity()
        {
            throw new NotImplementedException();
        }

        public void Remove(StoreItem entity)
        {
            throw new NotImplementedException();
        }

        public void Update(StoreItem entity)
        {
            throw new NotImplementedException();
        }
    }
}
