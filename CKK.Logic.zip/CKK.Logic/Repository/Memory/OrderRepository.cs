﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CKK.Logic.Repository.Memory
{
    public class OrderRepository : IOrderRepository
    {
        public void Add(OrderSummary entity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderSummary> GetAll()
        {
            throw new NotImplementedException();
        }

        public Order GetOrderByCustomerId(int id)
        {
            throw new NotImplementedException();
        }

        public void Remove(OrderSummary entity)
        {
            throw new NotImplementedException();
        }

        public void Update(OrderSummary entity)
        {
            throw new NotImplementedException();
        }
    }
}
