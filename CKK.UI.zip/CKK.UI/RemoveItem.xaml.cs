﻿using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for RemoveItem.xaml
    /// </summary>
    public partial class RemoveItem : Window
    {
        public Homepage homepage;

        public RemoveItem()
        {
            InitializeComponent();
        }

        private void RemoveItemButton_Click(object sender, System.EventArgs e)
        {
            int _resultParse = -1;
            if(int.TryParse(IdBox.Text, out _resultParse))
            {
                homepage.dStore.DeleteProduct(_resultParse);
                homepage.RefreshList();
            }

            this.Close();
        }
    }
}
