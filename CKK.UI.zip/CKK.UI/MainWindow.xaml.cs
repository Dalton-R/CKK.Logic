﻿using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, System.EventArgs e)
        {
            if (UsernameBox.Text == "User" && PasswordBox.Password == "Passw0rd")
            {
                Homepage homepage = new Homepage();
                homepage.Show();
                this.Close();
            }
        }
    }
}
