﻿using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using CKK.Logic.Repository.Implementation;
using CKK.Logic.Repository.Interfaces;
using CKK.Persistance.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for Homepage.xaml
    /// </summary>
    public partial class Homepage : Window
    {
        //public FileStore fStore;
        //public ObservableCollection<StoreItem> _Items = new ObservableCollection<StoreItem>()

        public DataStore dStore;

        public Homepage()
        {
            //fStore = (FileStore)Application.Current.FindResource("FStore");

            dStore = new DataStore(new ProductRepository(new DatabaseConnectionFactory()));
            dStore.Items = new List<StoreItem>();
            /*
            IConnectionFactory iConn = new IConnectionFactory();
            ProductRepository prodRep = new ProductRepository(iConn);
            dStore = new DataStore(prodRep);
            */

            InitializeComponent();
            RefreshList();
        }

        public void RefreshList()
        {
            /*
            fStore.Load();

            _Items.Clear();
            foreach(StoreItem si in new ObservableCollection<StoreItem>(fStore.GetStoreItems()))
            {
                _Items.Add(si);
            }

            string _list = "";
            foreach(StoreItem si in _Items)
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
            */

            string _list = "";
            foreach (Product si in dStore.GetAllProducts())
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;

        }

        public void SetList(List<Product> items)
        {
            string _list = "";
            foreach (Product si in dStore.GetAllProducts())
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
        }

        private void LogOutButton_Click(object sender, System.EventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            AddItem addItemWindow = new AddItem();
            addItemWindow.Show();
            addItemWindow.homepage = this;
        }

        private void RemoveItemButton_Click(object sender, System.EventArgs e)
        {
            RemoveItem removeItemWindow = new RemoveItem();
            removeItemWindow.Show();
            removeItemWindow.homepage = this;
        }

        private void FindNameButton_Click(object sender, System.EventArgs e)
        {
            //List<StoreItem> _items = fStore.GetAllProductsByName(SearchBox.Text);
            List<Product> _items = dStore.GetAllProducts();
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortQuantityButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            //List<StoreItem> _items = fStore.GetProductsByQuantity();
            List<Product> _items = dStore.GetAllProducts();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortPriceButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            //List<StoreItem> _items = fStore.GetProductsByPrice();
            List<Product> _items = dStore.GetAllProducts();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void ClearFilterButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = false;
            RefreshList();
        }
    }
}
