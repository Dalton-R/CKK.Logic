﻿using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using CKK.Persistance.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for Homepage.xaml
    /// </summary>
    public partial class Homepage : Window
    {
        public FileStore fStore;
        public ObservableCollection<StoreItem> _Items { get; private set; }

        public Homepage()
        {
            fStore = (FileStore)Application.Current.FindResource("FStore");
            InitializeComponent();
            _Items = new ObservableCollection<StoreItem>();
            RefreshList();
        }

        public void RefreshList()
        {
            fStore.Load();

            _Items.Clear();
            foreach(StoreItem si in new ObservableCollection<StoreItem>(fStore.GetStoreItems()))
            {
                _Items.Add(si);
            }

            string _list = "";
            foreach(StoreItem si in _Items)
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
        }

        public void SetList(List<StoreItem> items)
        {
            string _list = "";
            foreach (StoreItem si in items)
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
        }

        private void LogOutButton_Click(object sender, System.EventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            AddItem addItemWindow = new AddItem();
            addItemWindow.Show();
            addItemWindow.homepage = this;
        }

        private void RemoveItemButton_Click(object sender, System.EventArgs e)
        {
            RemoveItem removeItemWindow = new RemoveItem();
            removeItemWindow.Show();
            removeItemWindow.homepage = this;
        }

        private void FindNameButton_Click(object sender, System.EventArgs e)
        {
            List<StoreItem> _items = fStore.GetAllProductsByName(SearchBox.Text);
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortQuantityButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            List<StoreItem> _items = fStore.GetProductsByQuantity();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortPriceButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            List<StoreItem> _items = fStore.GetProductsByPrice();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void ClearFilterButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = false;
            RefreshList();
        }
    }
}
