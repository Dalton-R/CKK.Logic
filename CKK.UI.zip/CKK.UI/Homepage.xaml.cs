﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Implementation;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for Homepage.xaml
    /// </summary>
    public partial class Homepage : Window
    {
        public DataStore dStore;

        public Homepage()
        {
            dStore = new DataStore(new ProductRepository(new DatabaseConnectionFactory()));
            dStore.Items = new List<StoreItem>();
            InitializeComponent();
            RefreshList();
        }

        public void RefreshList()
        {
            string _list = "";
            foreach (Product si in dStore.GetAllProducts())
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;

        }

        public void SetList(List<Product> items)
        {
            string _list = "";
            foreach (Product si in items)
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
        }

        private void LogOutButton_Click(object sender, System.EventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            AddItem addItemWindow = new AddItem();
            addItemWindow.Show();
            addItemWindow.homepage = this;
        }

        private void EditItemButton_Click(object sender, System.EventArgs e)
        {
            FindEditItem editItemWindow = new FindEditItem();
            editItemWindow.homepage = this;
            editItemWindow.Show();
        }

        private void RemoveItemButton_Click(object sender, System.EventArgs e)
        {
            RemoveItem removeItemWindow = new RemoveItem();
            removeItemWindow.homepage = this;
            removeItemWindow.Show();
        }

        private void FindNameButton_Click(object sender, System.EventArgs e)
        {
            List<Product> _items = dStore.GetAllProducts();
            _items = _items.Where(f => f.Name.ToLower().Contains(SearchBox.Text.ToLower())).ToList();
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortQuantityButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            List<Product> _items = dStore.GetAllProducts();
            _items = _items.OrderByDescending(f => f.Quantity).ToList();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void SortPriceButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            List<Product> _items = dStore.GetAllProducts();
            _items = _items.OrderByDescending(f => f.Price).ToList();
            ClearFilterButton.IsEnabled = true;
            SetList(_items);
        }

        private void ClearFilterButton_Click(object sender, System.EventArgs e)
        {
            SearchBox.Text = "";
            ClearFilterButton.IsEnabled = false;
            RefreshList();
        }
    }
}




// HELPFUL CODE

//public FileStore fStore;
//public ObservableCollection<StoreItem> _Items = new ObservableCollection<StoreItem>()

// homepage
//fStore = (FileStore)Application.Current.FindResource("FStore");

/*
fStore.Load();

_Items.Clear();
foreach(StoreItem si in new ObservableCollection<StoreItem>(fStore.GetStoreItems()))
{
    _Items.Add(si);
}

string _list = "";
foreach(StoreItem si in _Items)
{
    _list += " - " + si.ItemToString() + "\n";
}

TxtBody.Text = _list;
*/