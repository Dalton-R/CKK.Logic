﻿using CKK.Logic.Interfaces;
using CKK.Logic.Models;
using CKK.Persistance.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for Homepage.xaml
    /// </summary>
    public partial class Homepage : Window
    {
        //public IStore _Store;
        public FileStore _Store;
        public ObservableCollection<StoreItem> _Items { get; private set; }

        public Homepage()
        {
            _Store = (FileStore)Application.Current.FindResource("globStore");
            InitializeComponent();
            _Items = new ObservableCollection<StoreItem>();
            RefreshList();
        }

        public void RefreshList()
        {
            _Store.Load();

            _Items.Clear();
            foreach(StoreItem si in new ObservableCollection<StoreItem>(_Store.GetStoreItems()))
            {
                _Items.Add(si);
            }

            string _list = "";
            foreach(StoreItem si in _Items)
            {
                _list += " - " + si.ItemToString() + "\n";
            }

            TxtBody.Text = _list;
        }

        private void LogOutButton_Click(object sender, System.EventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            AddItem addItemWindow = new AddItem();
            addItemWindow.Show();
            addItemWindow.homepage = this;
        }

        private void RemoveItemButton_Click(object sender, System.EventArgs e)
        {
            RemoveItem removeItemWindow = new RemoveItem();
            removeItemWindow.Show();
            removeItemWindow.homepage = this;
        }
    }
}
