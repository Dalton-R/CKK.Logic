﻿using CKK.Logic.Models;
using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for RemoveItem.xaml
    /// </summary>
    public partial class FindEditItem : Window
    {
        public Homepage homepage;

        public FindEditItem()
        {
            InitializeComponent();
        }

        private void FindEditItemButton_Click(object sender, System.EventArgs e)
        {
            int _resultParse = -1;
            if(int.TryParse(IdBox.Text, out _resultParse))
            {
                //homepage.dStore.DeleteProduct(_resultParse);
                //homepage.RefreshList();

                foreach (Product prod in homepage.dStore.GetAllProducts())
                {
                    if (_resultParse == prod.Id)
                    {
                        EditItem editItemWindow = new EditItem(homepage, prod);
                        editItemWindow.Show();
                        editItemWindow.sentprod = prod;
                        editItemWindow.homepage = homepage;
                        break;
                    }
                }
            }

            this.Close();
        }
    }
}
