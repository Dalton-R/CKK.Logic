﻿using CKK.Logic.Models;
using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for AddItem.xaml
    /// </summary>
    public partial class EditItem : Window
    {
        public Homepage homepage;
        public Product sentprod;

        public EditItem(Homepage _page, Product _prod)
        {
            InitializeComponent();

            homepage = _page;
            sentprod = _prod;

            NameBox.Text = sentprod.Name;
            QuantityBox.Text = sentprod.Quantity.ToString();
            PriceBox.Text = sentprod.Price.ToString();
        }

        private void EditItemButton_Click(object sender, System.EventArgs e)
        {
            bool _canAdd = true;

            string _name = NameBox.Text;
            int _resultQuantity = -1;
            if (!int.TryParse(QuantityBox.Text, out _resultQuantity))
            {
                _canAdd = false;
            }
            decimal _resultPrice = -1;
            if (!decimal.TryParse(PriceBox.Text, out _resultPrice))
            {
                _canAdd = false;
            }

            if (_resultPrice < 0 || _resultQuantity < 0)
            {
                _canAdd = false;
            }

            if (string.IsNullOrEmpty(_name) || string.IsNullOrWhiteSpace(_name))
            {
                _canAdd = false;
            }

            if (_canAdd)
            {
                Product prod = new Product();
                prod.Name = _name;
                prod.Id = sentprod.Id;
                prod.Price = _resultPrice;
                prod.Quantity = _resultQuantity;

                bool _already = false;
                foreach(Product _prod in homepage.dStore.GetAllProducts())
                {
                    if(_prod.Id == prod.Id)
                    {
                        homepage.dStore.UpdateProduct(prod);

                        _already = true;
                        break;
                    }
                }

                if (!_already)
                {
                    homepage.dStore.AddProduct(prod);
                }
                homepage.RefreshList();
            }

            this.Close();
        }
    }
}
