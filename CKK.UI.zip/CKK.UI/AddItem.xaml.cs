﻿using CKK.Logic.Models;
using System.Windows;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for AddItem.xaml
    /// </summary>
    public partial class AddItem : Window
    {
        public Homepage homepage;

        public AddItem()
        {
            InitializeComponent();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            bool _canAdd = true;

            string _name = NameBox.Text;
            int _resultId = -1;
            if (!int.TryParse(IdBox.Text, out _resultId))
            {
                _canAdd = false;
            }
            int _resultQuantity = -1;
            if (!int.TryParse(QuantityBox.Text, out _resultQuantity))
            {
                _canAdd = false;
            }
            decimal _resultPrice = -1;
            if (!decimal.TryParse(PriceBox.Text, out _resultPrice))
            {
                _canAdd = false;
            }

            if(_resultPrice < 0 || _resultQuantity < 0 || _resultId < 0)
            {
                _canAdd = false;
            }

            foreach(Product prod in homepage.dStore.GetAllProducts())
            {
                if(_resultId == prod.Id)
                {
                    _canAdd = false;
                    break;
                }
            }

            if(string.IsNullOrEmpty(_name) || string.IsNullOrWhiteSpace(_name))
            {
                _canAdd = false;
            }

            if (_canAdd)
            {
                Product prod = new Product();
                prod.Name = _name;
                prod.Id = _resultId;
                prod.Price = _resultPrice;
                prod.Quantity = _resultQuantity;

                bool _already = false;
                foreach(Product _prod in homepage.dStore.GetAllProducts())
                {
                    if(_prod.Id == prod.Id)
                    {
                        homepage.dStore.UpdateProduct(prod);

                        _already = true;
                        break;
                    }
                }

                if (!_already)
                {
                    homepage.dStore.AddProduct(prod);
                }
                homepage.RefreshList();
            }

            this.Close();
        }
    }
}
