﻿using CKK.Logic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CKK.UI
{
    /// <summary>
    /// Interaction logic for AddItem.xaml
    /// </summary>
    public partial class AddItem : Window
    {
        public Homepage homepage;

        public AddItem()
        {
            InitializeComponent();
        }

        private void AddItemButton_Click(object sender, System.EventArgs e)
        {
            string _name = NameBox.Text;
            int _id = int.Parse(IdBox.Text);
            int _quantity = int.Parse(QuantityBox.Text);
            decimal _price = decimal.Parse(PriceBox.Text);

            Product prod = new Product();
            prod.Name = _name;
            prod.Id = _id;
            prod.Price = _price;

            //homepage.dStore.AddStoreItem(prod, _quantity);
            homepage.dStore.AddProduct(prod);
            homepage.RefreshList();

            this.Close();
        }
    }
}
